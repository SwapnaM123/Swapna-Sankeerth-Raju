﻿using JobApplication.Common.Models;
using Job.Application.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Job.Application.Data.Services.Derived
{
    public  class UserDetailsService:UserDetails
    {
        jobapplicationContext db = new jobapplicationContext();



        public override int AddUser(Users users)
        {
            db.Users.Add(users);
            int recordInserted = db.SaveChanges();
            return recordInserted;
        }



        public override List<Users> GetallUsers()
        {
            return db.Users.ToList();
        }
    }
}
