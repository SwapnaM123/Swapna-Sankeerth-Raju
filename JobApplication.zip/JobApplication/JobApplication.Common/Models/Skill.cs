﻿using System;
using System.Collections.Generic;

namespace JobApplication.Common.Models
{
    public partial class Skill
    {
        public int SkillId { get; set; }
        public string SkillName { get; set; }
    }
}
