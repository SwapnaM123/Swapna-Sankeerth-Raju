﻿using JobApplication.Common.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job.Application.Data.Services.Abstract
{
    public abstract class JobProfile
    {
        public abstract List<JobProfilesViewModel> GetAllJobDetails();
        public abstract int AddJobDetails(JobProfiles jobProfiles);
        public abstract JobProfilesViewModel GetJobDetailsByJobId(int jobId);
        public abstract List<JobProfiles> SearchJobDetails(JobProfiles jobProfiles);
        public abstract List<JobProfilesViewModel> GetJobDetailsByAvailability(string availability);
        public abstract List<JobProfilesViewModel> GetJobDetailsByType(string jobType);
        public abstract List<JobProfilesViewModel> GetJobDetailsByExperience(int experience);
        public abstract List<JobProfilesViewModel> GetJobDetailsByCountry(string country);
        public abstract List<JobProfilesViewModel> GetJobDetailsBySkills(string skillName);
        public abstract List<JobProfilesViewModel> GetJobDetailsByLanguage(string language);
        public abstract List<JobProfilesViewModel> GetJobDetailsByPayrate(int payRate);
        public abstract string AddJobDetailsByExcelData(string fileName);
    }
}
