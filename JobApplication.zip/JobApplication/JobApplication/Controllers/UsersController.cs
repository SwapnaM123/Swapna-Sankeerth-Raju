﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Job.Application.Data.Services.Abstract;
using JobApplication.Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Job.Application.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserDetails _userDetails;



        public UsersController(UserDetails userDetails)
        {
            _userDetails = userDetails;
        }



        [HttpGet("GetAllUsers")]
        public IActionResult GetAllUsers()
        {
            var data = _userDetails.GetallUsers();
            if (data != null)
            {
                return Ok(new { status = 200, success = true, response = data });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Details not found" });
            }
        }



        [HttpPost("AddUser")]
        public IActionResult AddUser(Users users)
        {
            int data = _userDetails.AddUser(users);
            if (data > 0)
            {
                return Ok(new { status = 200, success = true, response = "User added successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, response = "Data not registered" });
            }
        }
    }
}
