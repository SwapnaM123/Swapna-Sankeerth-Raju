﻿using System;
using System.Collections.Generic;

namespace JobApplication.Common.Models
{
    public partial class Users
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}
